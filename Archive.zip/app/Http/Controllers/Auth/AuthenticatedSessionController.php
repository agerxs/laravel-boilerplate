<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Inertia\Response;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): Response
    {
        return Inertia::render('Auth/Login', [
            'canResetPassword' => Route::has('password.request'),
            'status' => session('status'),
            'appVersion' => config('app.version'),
            'appName' => config('app.name'),
        ]);
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        \Log::info("AuthenticatedSessionController::store() - Tentative de connexion", [
            'email' => $request->email,
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        try {
            $request->authenticate();
            
            $user = \Illuminate\Support\Facades\Auth::user();
            \Log::info("AuthenticatedSessionController::store() - Connexion réussie", [
                'user_id' => $user->id,
                'email' => $user->email,
                'name' => $user->name,
                'is_super_admin' => $user->is_super_admin,
                'roles' => $user->roles->pluck('name')->toArray(),
                'canViewDashboard' => $user->canViewDashboard(),
                'ip' => $request->ip()
            ]);

            $request->session()->regenerate();

            return redirect()->intended(route('dashboard', absolute: false));
        } catch (\Exception $e) {
            \Log::warning("AuthenticatedSessionController::store() - Échec de connexion", [
                'email' => $request->email,
                'error' => $e->getMessage(),
                'ip' => $request->ip()
            ]);
            throw $e;
        }
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $user = Auth::user();
        
        if ($user) {
            \Log::info("AuthenticatedSessionController::destroy() - Déconnexion", [
                'user_id' => $user->id,
                'email' => $user->email,
                'name' => $user->name,
                'ip' => $request->ip()
            ]);
        }

        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
