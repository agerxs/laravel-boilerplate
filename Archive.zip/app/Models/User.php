<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Althinect\FilamentSpatieRolesPermissions\Concerns\HasSuperAdmin;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles, HasSuperAdmin, SoftDeletes, HasApiTokens;

    /**
     * Les attributs qui peuvent être affectés en masse.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'locality_id',
        'organization_id',
        'job_function_id',
        'contract_type_id',
        'assignment_location_id',
        'cni_number',
        'cnam_number',
        'phone',
    ];

    /**
     * Les attributs qui doivent être cachés pour les tableaux.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Les attributs qui devraient être castés.
     *
     * @var array<int, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function locality(): BelongsTo
    {
        return $this->belongsTo(Locality::class);
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function jobFunction(): BelongsTo
    {
        return $this->belongsTo(JobFunction::class);
    }

    public function contractType(): BelongsTo
    {
        return $this->belongsTo(ContractType::class);
    }

    public function assignmentLocation(): BelongsTo
    {
        return $this->belongsTo(AssignmentLocation::class);
    }

    /**
     * Obtient le rôle principal de l'utilisateur
     */
    public function getPrimaryRole()
    {
        return $this->roles()->first();
    }

    /**
     * Vérifie si l'utilisateur est un super admin
     */
    public function isSuperAdmin(): bool
    {
        $result = $this->is_super_admin || $this->hasRole('super_admin');
        \Log::info("User::isSuperAdmin() - Email: {$this->email}, is_super_admin: " . ($this->is_super_admin ? 'true' : 'false') . ", hasRole(super_admin): " . ($this->hasRole('super_admin') ? 'true' : 'false') . ", result: " . ($result ? 'true' : 'false'));
        return $result;
    }

    /**
     * Vérifie si l'utilisateur est un admin simple
     */
    public function isAdmin(): bool
    {
        $hasAdminRole = $this->hasRole('admin');
        $isSuperAdmin = $this->isSuperAdmin();
        $result = $hasAdminRole && !$isSuperAdmin;
        \Log::info("User::isAdmin() - Email: {$this->email}, hasRole(admin): " . ($hasAdminRole ? 'true' : 'false') . ", isSuperAdmin(): " . ($isSuperAdmin ? 'true' : 'false') . ", result: " . ($result ? 'true' : 'false'));
        return $result;
    }

    /**
     * Vérifie si l'utilisateur peut modifier les éléments du dashboard
     */
    public function canModifyDashboard(): bool
    {
        return $this->isSuperAdmin();
    }

    /**
     * Vérifie si l'utilisateur peut voir le dashboard
     */
    public function canViewDashboard(): bool
    {
        $isSuperAdmin = $this->isSuperAdmin();
        $isAdmin = $this->isAdmin();
        $result = $isSuperAdmin || $isAdmin;
        \Log::info("User::canViewDashboard() - Email: {$this->email}, isSuperAdmin(): " . ($isSuperAdmin ? 'true' : 'false') . ", isAdmin(): " . ($isAdmin ? 'true' : 'false') . ", result: " . ($result ? 'true' : 'false'));
        return $result;
    }

    public function submittedPaymentLists(): HasMany
    {
        return $this->hasMany(MeetingPaymentList::class, 'submitted_by');
    }

    public function validatedPaymentLists(): HasMany
    {
        return $this->hasMany(MeetingPaymentList::class, 'validated_by');
    }

    public function localCommitteeMembers(): HasMany
    {
        return $this->hasMany(LocalCommitteeMember::class, 'user_id');
    }

    public function localCommittees(): BelongsToMany
    {
        return $this->belongsToMany(LocalCommittee::class, 'local_committee_members', 'user_id', 'local_committee_id')
            ->withPivot('role', 'status');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function meetingAttendances(): HasMany
    {
        return $this->hasMany(MeetingAttendee::class);
    }
}
