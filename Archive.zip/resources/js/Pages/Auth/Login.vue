<script setup lang="ts">
import Checkbox from '@/Components/Checkbox.vue';
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import QuickLogin from '@/Components/QuickLogin.vue';

defineProps<{
    canResetPassword?: boolean;
    status?: string;
    actionUrl?: string;
    appVersion?: string;
    appName?: string;
}>();

const form = useForm({
    email: '',
    password: '',
    remember: false,
});

const submit = () => {
    form.post(route('login'), {
        onFinish: () => {
            form.reset('password');
        },
    });
};

// Fonctions pour la connexion rapide
const loginAsAdmin = () => {
    form.email = 'superadmin@colocs.ci';
    form.password = 'password123';
    submit();
};

const loginAsSousPrefet = () => {
    form.email = 'president@test.com';
    form.password = 'password123';
    submit();
};

const loginAsSecretaire = () => {
    form.email = 'secretaire@test.com';
    form.password = 'password123';
    submit();
};

const loginAsGestionnaire = () => {
    form.email = 'tresorier@test.com';
    form.password = 'password123';
    submit();
};

const loginAsAdminSimple = () => {
    form.email = 'admin@colocs.ci';
    form.password = 'password123';
    submit();
};
</script>

<template>
    <GuestLayout>
        <Head title="Connexion" />

        <div v-if="status" class="mb-4 text-sm font-medium text-green-600">
            {{ status }}
        </div>

        <form @submit.prevent="submit">
            <div>
                <InputLabel for="email" value="Email" />

                <TextInput
                    id="email"
                    type="email"
                    class="mt-1 block w-full"
                    v-model="form.email"
                    required
                    autofocus
                    autocomplete="username"
                />

                <InputError class="mt-2" :message="form.errors.email" />
            </div>

            <div class="mt-4">
                <InputLabel for="password" value="Mot de passe" />

                <TextInput
                    id="password"
                    type="password"
                    class="mt-1 block w-full"
                    v-model="form.password"
                    required
                    autocomplete="current-password"
                />

                <InputError class="mt-2" :message="form.errors.password" />
            </div>

            <div class="mt-4 block">
                <label class="flex items-center">
                    <Checkbox name="remember" v-model:checked="form.remember" />
                    <span class="ms-2 text-sm text-gray-600">
                        Se souvenir de moi
                    </span>
                </label>
            </div>

            <div class="mt-4 flex items-center justify-end">
                <Link
                    v-if="canResetPassword"
                    :href="route('password.request')"
                    class="rounded-md text-sm text-gray-600 underline hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                >
                    Mot de passe oublié ?
                </Link>

                <PrimaryButton
                    class="ms-4"
                    :class="{ 'opacity-25': form.processing }"
                    :disabled="form.processing"
                >
                    Se connecter
                </PrimaryButton>
            </div>
        </form>

        <!-- Boutons de connexion rapide pour la démo -->
        <div class="mt-8">
            <div class="relative">
                <div class="absolute inset-0 flex items-center" aria-hidden="true">
                    <div class="w-full border-t border-gray-200"></div>
                </div>
                <div class="relative flex justify-center text-sm font-medium leading-6">
                    <span class="bg-white px-6 text-gray-900">Connexion rapide (démo)</span>
                </div>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-3">
                <button
                    type="button"
                    @click="loginAsAdmin"
                    class="flex w-full items-center justify-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                    Super Admin
                </button>
                <button
                    type="button"
                    @click="loginAsAdminSimple"
                    class="flex w-full items-center justify-center rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                >
                    Admin
                </button>
                <button
                    type="button"
                    @click="loginAsSousPrefet"
                    class="flex w-full items-center justify-center rounded-md bg-yellow-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-yellow-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-yellow-600"
                >
                    Président
                </button>
                <button
                    type="button"
                    @click="loginAsSecretaire"
                    class="flex w-full items-center justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-green-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-600"
                >
                    Secrétaire
                </button>
                <button
                    type="button"
                    @click="loginAsGestionnaire"
                    class="flex w-full items-center justify-center rounded-md bg-purple-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-purple-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-purple-600"
                >
                    Trésorier
                </button>
            </div>
        </div>

        <!-- Affichage de la version -->
        <div class="mt-8 text-center">
            <div class="text-xs text-gray-500">
                <div class="font-medium">{{ appName || 'COLOC-CMU' }}</div>
                <div class="mt-1">
                    Version: <span class="font-mono bg-gray-100 px-2 py-1 rounded">{{ appVersion || '1.0.0' }}</span>
                </div>
                <div class="mt-1 text-gray-400">
                    Build: {{ new Date().toLocaleDateString('fr-FR') }}
                </div>
            </div>
        </div>

    </GuestLayout>
</template>

<style scoped>
/* Supprimer les anciennes classes si elles existent */
.eSignetA,
.eSignetB,
.eSignetC,
.eSignetD,
.eSignetE {
    all: unset;
}
</style>
