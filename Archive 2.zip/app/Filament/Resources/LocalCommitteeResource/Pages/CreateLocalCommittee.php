<?php

namespace App\Filament\Resources\LocalCommitteeResource\Pages;

use App\Filament\Resources\LocalCommitteeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLocalCommittee extends CreateRecord
{
    protected static string $resource = LocalCommitteeResource::class;
} 