<?php

namespace App\Filament\Resources\SecretaryResource\Pages;

use App\Filament\Resources\SecretaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSecretary extends CreateRecord
{
    protected static string $resource = SecretaryResource::class;
} 