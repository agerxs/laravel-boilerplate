<?php

namespace App\Http\Controllers;

use App\Models\LocalCommittee;
use App\Models\LocalCommitteeMember;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Services\AdministrativeDataService;

class LocalCommitteeController extends Controller
{
    public function index(Request $request)
    {
        $query = LocalCommittee::query()
            ->with('members')
            ->orderBy('created_at', 'desc');

        // Recherche
        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('city', 'like', "%{$search}%")
                  ->orWhere('address', 'like', "%{$search}%")
                  ->orWhereHas('members', function ($q) use ($search) {
                      $q->where('first_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%");
                  });
            });
        }

        // Pagination
        $perPage = $request->get('per_page', 10);
        $committees = $query->paginate($perPage);

        return Inertia::render('LocalCommittees/Index', [
            'committees' => $committees,
            'filters' => [
                'search' => $request->get('search', ''),
                'per_page' => $perPage
            ]
        ]);
    }

    public function create()
    {
        $administrativeService = new AdministrativeDataService();
        
        return Inertia::render('LocalCommittees/Create', [
            'users' => User::select('id', 'name', 'email')->orderBy('name')->get(),
            'localities' => $administrativeService->getAllLocalities(),
            'topLevelLocalities' => $administrativeService->getLocalitiesByParent(null)
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'city' => 'required|string',
            'address' => 'required|string',
            'members' => 'required|array|min:1',
            'members.*.user_id' => 'required|exists:users,id',
            'members.*.role' => 'required|string|in:president,secretary,treasurer,member'
        ]);

        $committee = LocalCommittee::create([
            'name' => $validated['name'],
            'description' => $validated['description'],
            'city' => $validated['city'],
            'address' => $validated['address']
        ]);

        // Attacher les membres avec leurs rôles
        foreach ($validated['members'] as $member) {
            $committee->members()->create([
                'user_id' => $member['user_id'],
                'role' => $member['role']
            ]);
        }

        return redirect()->route('local-committees.index')
            ->with('success', 'Comité local créé avec succès');
    }

    public function edit(LocalCommittee $localCommittee)
    {
        $localCommittee->load('members');

        return Inertia::render('LocalCommittees/Edit', [
            'committee' => $localCommittee,
            'users' => User::select('id', 'name', 'email')->get()
        ]);
    }

    public function update(Request $request, LocalCommittee $localCommittee)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'city' => 'required|string',
            'address' => 'required|string',
            'members' => 'required|array|min:1',
            'members.*.user_id' => 'required|exists:users,id',
            'members.*.role' => 'required|string|in:president,secretary,treasurer,member'
        ]);

        $localCommittee->update([
            'name' => $validated['name'],
            'description' => $validated['description'],
            'city' => $validated['city'],
            'address' => $validated['address']
        ]);

        // Supprimer tous les membres actuels
        $localCommittee->members()->delete();

        // Ajouter les nouveaux membres
        foreach ($validated['members'] as $member) {
            $localCommittee->members()->create([
                'user_id' => $member['user_id'],
                'role' => $member['role']
            ]);
        }

        return redirect()->route('local-committees.index')
            ->with('success', 'Comité local mis à jour avec succès');
    }

    public function destroy(LocalCommittee $localCommittee)
    {
        $localCommittee->delete();

        return redirect()->route('local-committees.index')
            ->with('success', 'Comité local supprimé avec succès');
    }

    public function show(LocalCommittee $localCommittee)
    {
        $localCommittee->load(['members', 'meetings' => function ($query) {
            $query->orderBy('start_datetime', 'desc');
        }]);
        
        return Inertia::render('LocalCommittees/Show', [
            'committee' => $localCommittee
        ]);
    }
} 