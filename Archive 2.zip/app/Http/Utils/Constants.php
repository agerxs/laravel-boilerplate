<?php


namespace App\Http\Utils;


class Constants
{
        const JSON_STATUS_SUCCESS='success';
        const JSON_STATUS_ERROR='error';


}
