<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/smartaxis/devapps/wuri/meeting-lara/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>