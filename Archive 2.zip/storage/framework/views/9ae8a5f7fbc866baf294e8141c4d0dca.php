<?php $__env->startComponent('mail::message'); ?>
# Ordre du jour mis à jour

L'ordre du jour de la réunion "<?php echo e($meeting->title); ?>" a été mis à jour.

Date : <?php echo e($meeting->start_datetime->format('d/m/Y H:i')); ?>

Lieu : <?php echo e($meeting->location); ?>


<?php $__env->startComponent('mail::button', ['url' => route('meetings.show', $meeting)]); ?>
Voir la réunion
<?php echo $__env->renderComponent(); ?>

Cordialement,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?> <?php /**PATH /Users/smartaxis/devapps/wuri/meeting-lara/resources/views/emails/meetings/agenda-updated.blade.php ENDPATH**/ ?>