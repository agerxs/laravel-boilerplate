<?php echo e($slot); ?>

<?php /**PATH /Users/smartaxis/devapps/wuri/meeting-lara/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>