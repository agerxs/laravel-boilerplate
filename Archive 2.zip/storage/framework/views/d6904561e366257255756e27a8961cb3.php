<?php $__env->startComponent('mail::message'); ?>
# Compte rendu de réunion

Le compte rendu de la réunion "<?php echo e($meeting->title); ?>" est disponible.

**Informations générales :**
- Date : <?php echo e($meeting->start_datetime->format('d/m/Y H:i')); ?>

- Lieu : <?php echo e($meeting->location); ?>


**Participants :**
<?php $__currentLoopData = $meeting->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($participant->user ? $participant->user->name : $participant->guest_name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($meeting->agenda->count() > 0): ?>
**Ordre du jour :**
<?php $__currentLoopData = $meeting->agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($item->title); ?> (<?php echo e($item->duration_minutes); ?> minutes)
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

**Compte rendu :**
<?php echo $meeting->minutes->content; ?>


**Pièces jointes :**
- compte-rendu-<?php echo e($meeting->id); ?>.pdf (Compte rendu au format PDF)
<?php $__currentLoopData = $meeting->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($attachment->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startComponent('mail::button', ['url' => route('meetings.show', $meeting)]); ?>
Voir la réunion
<?php echo $__env->renderComponent(); ?>

Cordialement,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?> <?php /**PATH /Users/smartaxis/devapps/wuri/meeting-lara/resources/views/emails/meetings/minutes.blade.php ENDPATH**/ ?>