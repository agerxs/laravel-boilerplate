<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; }
        .header { text-align: center; margin-bottom: 30px; }
        .section { margin-bottom: 20px; }
        .agenda-item { margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($meeting->title); ?></h1>
        <p>Date : <?php echo e($meeting->start_datetime->format('d/m/Y H:i')); ?></p>
        <p>Lieu : <?php echo e($meeting->location); ?></p>
    </div>

    <div class="section">
        <h2>Ordre du jour</h2>
        <?php $__currentLoopData = $meeting->agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="agenda-item">
                <h3><?php echo e($item->title); ?></h3>
                <p><?php echo e($item->description); ?></p>
                <p>Durée : <?php echo e($item->duration_minutes); ?> minutes</p>
                <p>Présentateur : <?php echo e($item->presenter->name ?? 'Non assigné'); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($meeting->minutes): ?>
        <div class="section">
            <h2>Compte rendu</h2>
            <?php echo $meeting->minutes->content; ?>

        </div>
    <?php endif; ?>
</body>
</html> <?php /**PATH /Users/smartaxis/devapps/wuri/meeting-lara/resources/views/exports/meeting.blade.php ENDPATH**/ ?>