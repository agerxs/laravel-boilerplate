<?php $__env->startComponent('mail::message'); ?>
# Invitation à une réunion

Bonjour <?php echo e($guestName); ?>,

Vous êtes invité(e) à participer à la réunion "<?php echo e($meeting->title); ?>".

**Détails de la réunion :**
- Date : <?php echo e($meeting->start_datetime->format('d/m/Y H:i')); ?>

- Lieu : <?php echo e($meeting->location); ?>

- Description : <?php echo e($meeting->description); ?>


<?php if($meeting->agenda->count() > 0): ?>
**Ordre du jour :**
<?php $__currentLoopData = $meeting->agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($item->title); ?> (<?php echo e($item->duration_minutes); ?> minutes)
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->startComponent('mail::button', ['url' => route('meetings.show', $meeting)]); ?>
Voir les détails de la réunion
<?php echo $__env->renderComponent(); ?>

Cordialement,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?> <?php /**PATH /Users/smartaxis/devapps/wuri/meeting-lara/resources/views/emails/meetings/guest-invitation.blade.php ENDPATH**/ ?>