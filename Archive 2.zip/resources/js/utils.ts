import { useToast } from '@/Composables/useToast'

export const toast = useToast() 