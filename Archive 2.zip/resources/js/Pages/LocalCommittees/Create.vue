<template>
  <AppLayout title="Nouveau Comité Local">
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Nouveau Comité Local
      </h2>
    </template>

    <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
          <form @submit.prevent="submit">
            <!-- Informations de base -->
            <div class="mb-6">
              <div>
                <InputLabel for="name" value="Nom du comité" />
                <TextInput
                  id="name"
                  v-model="form.name"
                  type="text"
                  class="mt-1 block w-full"
                  required
                />
                <InputError :message="form.errors.name" class="mt-2" />
              </div>
            </div>

            <!-- Bloc localité -->
            <div class="mb-6">
              <h3 class="text-lg font-medium text-gray-900 mb-4">Localisation</h3>
              <LocalitySelector
                v-model="selectedLocation"
                :localities="localities"
              />
            </div>

            <!-- Adresse -->
            <div class="mb-6">
              <InputLabel for="address" value="Adresse complète" />
              <TextInput
                id="address"
                v-model="form.address"
                type="text"
                class="mt-1 block w-full"
                required
              />
              <InputError :message="form.errors.address" class="mt-2" />
            </div>

            <!-- Description -->
            <div class="mb-6">
              <InputLabel for="description" value="Description" />
              <TextArea
                id="description"
                v-model="form.description"
                class="mt-1 block w-full"
                :rows="3"
              />
              <InputError :message="form.errors.description" class="mt-2" />
            </div>

            <!-- Section des membres -->
            <div class="mt-6">
              <h3 class="text-lg font-medium text-gray-900">Membres du comité</h3>
              <p class="mt-1 text-sm text-gray-600">
                Sélectionnez les utilisateurs qui feront partie de ce comité
              </p>

              <div class="mt-4 space-y-4">
                <div v-for="(member, index) in form.members" :key="index" class="flex items-start space-x-4">
                  <!-- Sélection de l'utilisateur -->
                  <div class="flex-1">
                    <label class="block text-sm font-medium text-gray-700">Utilisateur</label>
                    <select
                      v-model="member.user_id"
                      class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      required
                    >
                      <option value="">Sélectionner un utilisateur</option>
                      <option
                        v-for="user in props.users"
                        :key="user.id"
                        :value="user.id"
                        :disabled="isUserSelected(user.id, index)"
                      >
                        {{ user.name }} ({{ user.email }})
                      </option>
                    </select>
                  </div>

                  <!-- Sélection du rôle -->
                  <div class="flex-1">
                    <label class="block text-sm font-medium text-gray-700">Rôle</label>
                    <select
                      v-model="member.role"
                      class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      required
                    >
                      <option value="">Sélectionner un rôle</option>
                      <option value="president">Président</option>
                      <option value="secretary">Secrétaire</option>
                      <option value="member">Membre</option>
                    </select>
                  </div>

                  <!-- Bouton de suppression -->
                  <button
                    type="button"
                    @click="removeMember(index)"
                    class="mt-6 p-2 text-red-600 hover:text-red-800"
                  >
                    <TrashIcon class="h-5 w-5" />
                  </button>
                </div>
              </div>

              <!-- Bouton pour ajouter un membre -->
              <button
                type="button"
                @click="addMember"
                class="mt-4 inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                <PlusIcon class="h-5 w-5 mr-2" />
                Ajouter un membre
              </button>
            </div>

            <div class="flex justify-end space-x-3">
              <Link
                :href="route('local-committees.index')"
                class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50"
              >
                Annuler
              </Link>
              <PrimaryButton :disabled="form.processing">
                Créer le comité
              </PrimaryButton>
            </div>
          </form>
        </div>
      </div>
    </div>
  </AppLayout>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useForm, Link } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'
import InputLabel from '@/Components/InputLabel.vue'
import TextInput from '@/Components/TextInput.vue'
import TextArea from '@/Components/TextArea.vue'
import InputError from '@/Components/InputError.vue'
import PrimaryButton from '@/Components/PrimaryButton.vue'
import { PlusIcon, TrashIcon } from '@heroicons/vue/24/outline'
import { useToast } from '@/Composables/useToast'
import LocalitySelector from '@/Components/LocalitySelector.vue'

const toast = useToast()

interface User {
  id: number
  name: string
  email: string
}

interface Props {
  users: User[]
  localities: any[]
}

const props = defineProps<Props>()

// État initial du formulaire
const initialFormState = {
  name: '',
  description: '',
  locality_id: '',
  address: '',
  members: [{
    user_id: '',
    role: ''
  }]
}

const form = useForm(initialFormState)

const selectedLocation = ref('')

// Surveiller les changements de localité pour mettre à jour l'adresse
watch(selectedLocation, (newLocation) => {
  if (newLocation) {
    // Si une adresse existe déjà, on la préserve en l'ajoutant à la fin
    const existingAddress = form.address.split(' - ')[1] || ''
    form.address = newLocation + (existingAddress ? ' - ' + existingAddress : '')
  }
})

// Filtrer les utilisateurs déjà sélectionnés
const availableUsers = computed(() => {
  if (!props.users) return []
  const selectedUserIds = form.members.map(m => m.user_id).filter(Boolean)
  return props.users.filter(user => {
    // Si l'utilisateur n'est pas sélectionné, il est disponible
    if (!selectedUserIds.includes(user.id)) return true
    // Si l'utilisateur est déjà sélectionné, il ne doit apparaître que dans sa propre liste
    return selectedUserIds.indexOf(user.id) === selectedUserIds.lastIndexOf(user.id)
  })
})

function isUserSelected(userId: number, currentIndex: number) {
  return form.members.some((member, index) => 
    member.user_id === userId && index !== currentIndex
  )
}

function addMember() {
  form.members.push({
    user_id: '',
    role: ''
  })
}

function removeMember(index: number) {
  if (form.members.length > 1) {
    form.members.splice(index, 1)
  } else {
    toast.error('Le comité doit avoir au moins un membre')
  }
}

function submit() {
  if (!form.members.length) {
    toast.error('Ajoutez au moins un membre')
    return
  }

  // S'assurer que l'adresse contient la localité
  if (selectedLocation.value && !form.address.startsWith(selectedLocation.value)) {
    form.address = selectedLocation.value + ' - ' + form.address
  }

  form.post(route('local-committees.store'), {
    onSuccess: () => {
      toast.success('Comité créé avec succès')
    },
    onError: () => {
      toast.error('Une erreur est survenue')
    }
  })
}
</script> 