<template>
  <AppLayout :title="`Modifier ${committee.name}`">
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Modifier {{ committee.name }}
      </h2>
    </template>

    <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
          <form @submit.prevent="submit">
            <!-- Informations du comité -->
            <div class="grid grid-cols-2 gap-6">
              <div>
                <InputLabel for="name" value="Nom du comité" />
                <TextInput
                  id="name"
                  v-model="form.name"
                  type="text"
                  class="mt-1 block w-full"
                  required
                />
                <InputError :message="form.errors.name" class="mt-2" />
              </div>

              <div>
                <InputLabel for="city" value="Localité" />
                <TextInput
                  id="city"
                  v-model="form.city"
                  type="text"
                  class="mt-1 block w-full"
                  required
                />
                <InputError :message="form.errors.city" class="mt-2" />
              </div>
            </div>

            <div>
              <InputLabel for="address" value="Adresse" />
              <TextInput
                id="address"
                v-model="form.address"
                type="text"
                class="mt-1 block w-full"
                required
              />
              <InputError :message="form.errors.address" class="mt-2" />
            </div>

            <div>
              <InputLabel for="description" value="Description" />
              <TextArea
                id="description"
                v-model="form.description"
                class="mt-1 block w-full"
                rows="3"
              />
              <InputError :message="form.errors.description" class="mt-2" />
            </div>

            <!-- Section des membres -->
            <div class="mt-6">
              <h3 class="text-lg font-medium text-gray-900">Membres du comité</h3>
              <p class="mt-1 text-sm text-gray-600">
                Gérez les membres de ce comité
              </p>

              <div class="mt-4 space-y-4">
                <div v-for="(member, index) in form.members" :key="index" class="flex items-start space-x-4">
                  <!-- Sélection de l'utilisateur -->
                  <div class="flex-1">
                    <label class="block text-sm font-medium text-gray-700">Utilisateur</label>
                    <select
                      v-model="member.user_id"
                      class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      required
                    >
                      <option value="">Sélectionner un utilisateur</option>
                      <option
                        v-for="user in availableUsers"
                        :key="user.id"
                        :value="user.id"
                        :disabled="isUserSelected(user.id, index)"
                      >
                        {{ user.name }} ({{ user.email }})
                      </option>
                    </select>
                  </div>

                  <!-- Sélection du rôle -->
                  <div class="flex-1">
                    <label class="block text-sm font-medium text-gray-700">Rôle</label>
                    <select
                      v-model="member.role"
                      class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      required
                    >
                      <option value="">Sélectionner un rôle</option>
                      <option value="president">Président</option>
                      <option value="secretary">Secrétaire</option>
                      <option value="member">Membre</option>
                    </select>
                  </div>

                  <!-- Bouton de suppression -->
                  <button
                    type="button"
                    @click="removeMember(index)"
                    class="mt-6 p-2 text-red-600 hover:text-red-800"
                  >
                    <TrashIcon class="h-5 w-5" />
                  </button>
                </div>
              </div>

              <!-- Bouton pour ajouter un membre -->
              <button
                type="button"
                @click="addMember"
                class="mt-4 inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                <PlusIcon class="h-5 w-5 mr-2" />
                Ajouter un membre
              </button>
            </div>

            <div class="flex justify-end space-x-3 mt-6">
              <Link
                :href="route('local-committees.index')"
                class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50"
              >
                Annuler
              </Link>
              <PrimaryButton :disabled="form.processing">
                Enregistrer les modifications
              </PrimaryButton>
            </div>
          </form>
        </div>
      </div>
    </div>
  </AppLayout>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useForm, Link } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'
import InputLabel from '@/Components/InputLabel.vue'
import TextInput from '@/Components/TextInput.vue'
import TextArea from '@/Components/TextArea.vue'
import InputError from '@/Components/InputError.vue'
import PrimaryButton from '@/Components/PrimaryButton.vue'
import { PlusIcon, TrashIcon } from '@heroicons/vue/24/outline'
import { useToast } from '@/Composables/useToast'

const toast = useToast()

interface User {
  id: number
  name: string
  email: string
}

interface Member {
  id?: number
  user_id: number
  role: string
}

interface Committee {
  id: number
  name: string
  description: string
  city: string
  address: string
  members: Member[]
}

interface Props {
  committee: Committee
  users: User[]
}

const props = defineProps<Props>()

const form = useForm({
  name: props.committee.name,
  description: props.committee.description,
  city: props.committee.city,
  address: props.committee.address,
  members: props.committee.members.map(member => ({
    id: member.id,
    user_id: member.user_id,
    role: member.role
  }))
})

// Filtrer les utilisateurs déjà sélectionnés
const availableUsers = computed(() => props.users)

function isUserSelected(userId: number, currentIndex: number) {
  return form.members.some((member, index) => 
    member.user_id === userId && index !== currentIndex
  )
}

function addMember() {
  form.members.push({
    user_id: '',
    role: ''
  })
}

function removeMember(index: number) {
  if (form.members.length > 1) {
    form.members.splice(index, 1)
  } else {
    toast.error('Le comité doit avoir au moins un membre')
  }
}

function submit() {
  form.put(route('local-committees.update', props.committee.id), {
    onSuccess: () => {
      toast.success('Comité modifié avec succès')
    }
  })
}
</script> 